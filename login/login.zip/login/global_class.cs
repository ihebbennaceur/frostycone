﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace login
{
     class global_class
    {
        public static List<Tuple<string, double, int>> items = new List<Tuple<string, double, int>> ();  //list stored as a global variable storing the product name, price and number of scoops

        
  
    }
}
